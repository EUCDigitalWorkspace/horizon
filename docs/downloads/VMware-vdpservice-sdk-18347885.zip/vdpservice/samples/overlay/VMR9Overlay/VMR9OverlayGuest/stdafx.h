/* ********************************************************************************* *
 * Copyright (C) 2011-2021 VMware, Inc.  All rights reserved. -- VMware Confidential *
 * ********************************************************************************* */

/*
 * StdAfx.h --
 *
 */

#pragma once
#include "targetver.h"
#include "..\VMR9OverlayClient\StdAfx.h"
