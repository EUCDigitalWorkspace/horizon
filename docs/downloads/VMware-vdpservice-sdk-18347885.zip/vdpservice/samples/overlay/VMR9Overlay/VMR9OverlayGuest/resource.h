//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by VMR9OverlayGuest.rc
//
#define IDC_MYICON                      2
#define IDD_VMR9OVERLAYGUEST_DIALOG     102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDC_VMR9OVERLAYGUEST2           104
#define IDM_EXIT                        105
#define IDI_VMR9OVERLAYGUEST            107
#define IDI_SMALL                       108
#define IDC_VMR9OVERLAYGUEST            109
#define IDR_MAINFRAME                   128
#define ID_FILE_OPEN                    32771
#define ID_FILE_ENABLE                  32772
#define ID_FILE_ENABLE_DISABLE          32773
#define ID_OVERLAY_ENABLE               32774
#define ID_OVERLAY_DISABLE              32775
#define ID_FILE_CLOSE                   32776
#define ID_PLAYBACK_START               32777
#define ID_PLAYBACK_STOP                32778
#define ID_PLAYBACK_SHOW                32779
#define ID_PLAYBACK_HIDE                32780
#define ID_PLAYBACK_COPYIMAGES          32781
#define ID_PLAYBACK_ENABLEOVERLAY       32782
#define ID_LAYOUT_CENTER                32783
#define ID_LAYOUT_TILE                  32784
#define ID_LAYOUT_SCALE                 32785
#define ID_LAYOUT_SCALE2                32786
#define ID_LAYOUT_SCALE3                32787
#define ID_LAYOUT_CROP                  32788
#define ID_LAYOUT_CROP2                 32789
#define ID_LAYOUT_CROP3                 32790
#define ID_LAYOUT_LETTERBOX             32791
#define ID_LAYOUT_LETTERBOX2            32792
#define ID_LAYOUT_LETTERBOX3            32793
#define ID_AREA_ENABLE                  32794
#define ID_AREA_POSITION                32795
#define ID_POSITION_CENTER              32796
#define ID_POSITION_TOP_LEFT            32797
#define ID_POSITION_TOP_RIGHT           32798
#define ID_POSITION_BOTTOM_LEFT         32799
#define ID_POSITION_BOTTOM_RIGHT        32800
#define ID_AREA_SIZE                    32801
#define ID_SIZE_16x9                    32802
#define ID_SIZE_4x3                     32803
#define ID_SIZE_1x1                     32804
#define ID_SIZE_VIDEO                   32805
#define ID_SIZE_WINDOW                  32806
#define ID_AREA_CLIPTOW                 32807
#define ID_AREA_CLIPTOWINDOW            32808
#define ID_PLAYBACK_ENABLECHILDWINDOW   32809
#define ID_PLAYBACK_BACKGROUND          32810
#define ID_BACKGROUND_DISABLED          32811
#define ID_BACKGROUND_BLACK             32812
#define ID_BACKGROUND_WHITE             32813
#define ID_BACKGROUND_RED               32814
#define ID_BACKGROUND_BLUE              32815
#define ID_BACKGROUND_PURPLE            32816
#define IDC_STATIC                      -1

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32817
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
