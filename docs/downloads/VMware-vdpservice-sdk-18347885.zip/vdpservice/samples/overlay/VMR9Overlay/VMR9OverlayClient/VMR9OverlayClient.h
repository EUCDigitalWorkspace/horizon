/* ********************************************************************************* *
 * Copyright (C) 2011-2021 VMware, Inc.  All rights reserved. -- VMware Confidential *
 * ********************************************************************************* */

/*
 * VMR9OverlayClient.h --
 *
 */

#ifndef VMR9OVERLAYCLIENT_H
#define VMR9OVERLAYCLIENT_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"

#endif // VMR9OVERLAYCLIENT_H
