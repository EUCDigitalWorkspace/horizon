//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by VMR9OverlayClient.rc
//
#define IDC_MYICON                      2
#define IDD_ALLOCATOR9_DIALOG           101
#define IDD_ABOUTBOX                    102
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_ALLOCATOR9                  107
#define IDI_SMALL                       108
#define IDC_ALLOCATOR9                  109
#define IDR_MAINFRAME                   128
#define ID_FILE_CLOSE                   134
#define IDM_PLAY_FILE                   32771
#define ID_PLAYBACK_USESWB              32772
#define ID_PLAYBACK_USED3D              32773
#define ID_PLAYBACK_OVERLAY             32774
#define ID_PLAYBACK_DIRECTX             32775
#define ID_PLAYBACK_START               32776
#define ID_PLAYBACK_STARTSTOP           32777
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
