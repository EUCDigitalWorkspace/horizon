/* ********************************************************************************* *
 * Copyright (C) 2011-2021 VMware, Inc.  All rights reserved. -- VMware Confidential *
 * ********************************************************************************* */

/*
 * stdafx.h --
 *
 */

#pragma once
#include "..\LocalOverlayClient\stdafx.h"
