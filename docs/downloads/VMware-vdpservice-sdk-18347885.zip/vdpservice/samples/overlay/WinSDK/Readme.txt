The files in the WinSDK folder came from the samples folder of WinSDK 6.0.
The complete SDK can be found here: www.microsoft.com/download/en/details.aspx?id=14477
